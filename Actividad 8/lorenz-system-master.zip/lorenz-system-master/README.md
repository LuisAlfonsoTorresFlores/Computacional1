# Lorenz System

Visualizations and animations of the Lorenz system with Python.

[![Animated Lorenz system attractor](images/animated-lorenz-attractor.gif)](lorenz-system-attractor-animate.ipynb)
